#! C:\python\venv\Scripts\python.exe

from clicknium import clicknium, ui, locator
from clicknium.common.enums import *
import subprocess
import os
from datetime import datetime, timedelta
import pandas as pd
import win32com.client as client
import glob
import requests
import json
import sys
import subprocess
import time
from dotenv import load_dotenv

# Carregar variáveis do arquivo .env
load_dotenv()

# Capturar a licença do Clicknium do .env
clicknium_license = os.getenv("CLICKNIUM_LICENSE")
autoit = client.Dispatch("AutoItX3.Control")
wshell = client.Dispatch("WScript.Shell")

clicknium.config.set_license(clicknium_license)

try:
    
    folder = sys.argv[1]
    excel_Processamento =  sys.argv[2]
    EnvMaxyCon = sys.argv[3]
    DataInicial = str(sys.argv[4])
    DataFinal = str(sys.argv[5])

except:

    folder = r"C:\python"
    excel_Processamento = f"{folder}\Lancamento_CTE.xlsx"
    EnvMaxyCon = " -url http://maxys.cjtrade.com.br:7777/forms/frmservlet?config=teste_app"
    DataInicial = "01/11/2024"
    DataFinal = "31/01/2025"
    pass

def SelecionaTabela():
    
    i=1

    CTE_Anterior = ""
    Transportadora_Anterior = ""

    while True:
        
        variables = {"linha": i}
            
        PesoDestino = ui(locator.java.maxys_TAF117.Tabela_pesodestino, variables).get_text().strip()
        CTE = ui(locator.java.maxys_TAF117.Tabela_text_cte, variables).get_text().strip()
        Transportadora = ui(locator.java.maxys_TAF117.Tabela_transp, variables).get_text().strip()

        if (CTE == CTE_Anterior and Transportadora == Transportadora_Anterior):
            break
        elif (CTE == "" and Transportadora == "" and PesoDestino == ""):
            break

        CTE_Anterior = CTE
        Transportadora_Anterior = Transportadora

        if PesoDestino != "" and ui(locator.java.maxys_TAF117.Tabela_check_box, variables).get_text() != "checked":
            ui(locator.java.maxys_TAF117.Tabela_check_box, variables).click()
            
        i+=1
        
        if i == 16:
            
            ui(locator.java.maxys_TAF117.Tabela_pesodestino, variables).click()
            ui(locator.java.maxys_TAF117.Tabela_pesodestino, variables).send_hotkey("{DOWN}")

            CTE = ui(locator.java.maxys_TAF117.Tabela_text_cte, variables).get_text().strip()
            Transportadora = ui(locator.java.maxys_TAF117.Tabela_transp, variables).get_text().strip()
            
            if CTE == CTE_Anterior and Transportadora == Transportadora_Anterior:
                break

            else:
                ui(locator.java.maxys_TAF117.Tabela_pesodestino, variables).send_hotkey("{DOWN 14}")
                i=1

def kill_Maxys_process():
    try:
        # Executa o comando 'taskkill' para encerrar processos Python
        result = subprocess.run(['taskkill', '/F', '/IM', 'java.exe'], capture_output=True, text=True)
        print(result.stdout)  # Exibe o resultado no terminal
    except Exception as e:
        print(f"Erro ao tentar encerrar o processo: {e}")

def _Login_MaxysErp(empresa):
    
    # Digita Login
    clicknium.wait_appear(locator.java.maxys.text_usuário)
    time.sleep(1)
    ui(locator.java.maxys.text_usuário).send_hotkey("{Tab}")
    time.sleep(1)

    # Digita Senha
    ui(locator.java.maxys.password_text_senha).send_hotkey("{Tab}")
    time.sleep(1)

    # Digita Empresa
    ui(locator.java.maxys.text_empresa).send_hotkey(empresa)
    time.sleep(1)

    # Click Ok
    clicknium.wait_appear(locator.java.maxys.push_button_ok_alt_o)
    time.sleep(1)
    ui(locator.java.maxys.push_button_ok_alt_o).click()

def _abrirMaxysErp():
    
    # Define the path to the executable
    executable_path = r"C:\Users\svc_rpa\AppData\Local\Maxicon Sistemas\Maxys\Maxys.exe"

    # Define the command-line parameter 
    parameter = EnvMaxyCon

    # Create the subprocess command as a list   
    command = [executable_path] + parameter.split()

    # Use subprocess.Popen to run the executable with the parameters
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True,shell=True)
    stdout, stderr = process.communicate()
    return_code = process.returncode

def _configJava():
    
    # Get username
    username = os.getenv("USERNAME")

    # Abrir o arquivo para escrita (modo 'w')
    accessibility_properties = rf'C:\Users\{username}\.accessibility.properties'

    with open(accessibility_properties, 'w') as a_p:
        
        # Escrever o novo conteúdo no arquivo
        a_p.write("assistive_technologies=com.clicknium.ClickniumJavaBridge")

def _Executar(tela):
    
    clicknium.wait_appear(locator.java.maxys.Executar_text)
    ui(locator.java.maxys.Executar_text).clear_text("send-hotkey")
    ui(locator.java.maxys.Executar_text).set_text(tela)
    ui(locator.java.maxys.Executar_text).send_hotkey("{ENTER}")

def _FecharSistema():
    
    # Fechar Telas
    autoit.WinActivate("MAXYS","")
    autoit.ControlSend("MAXYS","","","^{F4}")
    
    # Sair Programar
    if clicknium.is_existing(locator.java.maxys.SairDoPrograma):
        ui(locator.java.maxys.SairDoPrograma).click()

    if clicknium.is_existing(locator.java.maxys_VFS014.Observacao_Sucesso):
        Mensagem = ui(locator.java.maxys_VFS014.Observacao_Mensagem).get_text()
        ui(locator.java.maxys_VFS014.Observacao_OK).click()
        print(Mensagem)

    if clicknium.is_existing(locator.java.maxys_VFS014.Observacao_Sucesso):
        Mensagem = ui(locator.java.maxys_VFS014.Observacao_Mensagem).get_text()
        ui(locator.java.maxys_VFS014.Observacao_OK).click()
        print(Mensagem)

    #Fechar Maxicon
    if clicknium.is_existing(locator.java.maxys.FecharMaxicon):
        ui(locator.java.maxys.FecharMaxicon).click()
    if clicknium.is_existing(locator.java.maxys.push_button_Sim_FecharSistema):
        ui(locator.java.maxys.push_button_Sim_FecharSistema).click()

def _fechar_Observacao():
    if clicknium.is_existing(locator.java.maxys_VFS014.Observacao_Sucesso):
        Mensagem = ui(locator.java.maxys_VFS014.Observacao_Mensagem).get_text()
        ui(locator.java.maxys_VFS014.Observacao_OK).click()
        autoit.sleep(500)
        if Mensagem != "Processo finalizado com sucesso.":
            raise Exception(Mensagem)
        else:
            return Mensagem

def _fechar_Precaucao():
    if clicknium.is_existing(locator.java.maxys_TAF117.PopUp_precaucao):
        Mensagem = ui(locator.java.maxys_TAF117.precaucao_text_area).get_text()
        ui(locator.java.maxys_TAF117.precaucao_ok_alt_o).click()
        autoit.sleep(500)
        raise Exception(Mensagem)

if __name__ == "__main__":

    empresas = [
        [1, "CJ INTERNATIONAL BRASIL COMERCIAL"],
        [2, "CJ INTERNATIONAL BRASIL - PARANAGUA"],
        [3, "CJ INTERNATIONAL BRASIL - RIO VERDE"],
        [4, "CJ INTERNATIONAL BRASIL - LONDRINA"],
        [5, "CJ INTERNATIONAL BRASIL - PASSO FUNDO"],
        [6, "CJ INTERNATIONAL BRASIL - RIO GRANDE"],
        [7, "CJ INTERNATIONAL BRASIL - SORRISO"],
        [8, "CJ INTERNATIONAL BRASIL - SANTOS"],
        [9, "CJ INTERNATIONAL BRASIL - ARAGUARI"],
        [10, "CJ INTERNATIONAL BRASIL - QUERENCIA"],
        [11, "CJ INTERNATIONAL BRASIL - IMBITUBA"]
    ]

    today = datetime.now()

    if DataInicial == "None" and DataFinal == "None":
        DataInicial = (today - timedelta(days=2)).strftime('%d/%m/%Y')
        DataFinal = (today - timedelta(days=10)).strftime('%d/%m/%Y')

    # Lista para armazenar dados para criar o DataFrame
    data = []
    
    for empresa in empresas:
        cod_empresa = empresa[0]
        nome_empresa = empresa[1]
        Tipos_ctes = ["normal", "complementar", "substituição"]

        # Abrir o sistema e realizar login
        _abrirMaxysErp()
        _Login_MaxysErp(cod_empresa)

        for tipo_cte in Tipos_ctes:
            resultado_do_processamento = f"{folder}\\{cod_empresa}_{nome_empresa}_{tipo_cte}_{DataInicial.replace('/', '')}.xlsx"
            print(resultado_do_processamento)
            try:

                # Executar rotina no sistema
                _Executar("TAF117")

                clicknium.wait_appear(locator.java.maxys_TAF117.text_dt_emissão_inicial)

                # Configurar os filtros
                ui(locator.java.maxys_TAF117.text_empresa).set_text(cod_empresa)
                ui(locator.java.maxys_TAF117.text_dt_emissão_inicial).set_text(DataInicial)
                ui(locator.java.maxys_TAF117.text_dt_emissão_final).set_text(DataFinal)

                if tipo_cte == "normal":
                    ui(locator.java.maxys_TAF117.radio_button_ct_e_normal).click()
                elif tipo_cte == "complementar":
                    ui(locator.java.maxys_TAF117.radio_button_ct_e_complementar).click()
                elif tipo_cte == "substituição":
                    ui(locator.java.maxys_TAF117.radio_button_ct_e_de_substituição).click()

                # Consultar
                ui(locator.java.maxys_TAF117.push_button_f3_consultar).click()
                
                _fechar_Observacao()
                                
                # Marcar tudo peso Destino difernete de varia e gravar
                SelecionaTabela()
                
                # CLICK GRAVAR
                ui(locator.java.maxys_TAF117.push_button_gravar).click()
                
                Mensagem = ""
                Mensagem = _fechar_Observacao()
                _fechar_Precaucao()
                
                if Mensagem != "Processo finalizado com sucesso.":
                    
                    # Capturar os dados
                    clicknium.wait_appear(locator.java.maxys_TAF117.Resultado_do_processamento)
                    
                    json_data = []
                    columns = ["CTE", "Série", "Emissão", "Sucesso", "Resultado do lançamento"]
                    i = 0
                    previous_row = None  # Variável para armazenar a linha anterior

                    while True:
                        row_data = {}
                        for column in columns:
                            variables = {"index": i, "name_column": column}
                            text = ui(locator.java.maxys_TAF117.text_Tabela, variables).get_text().strip()
                            row_data[column] = text

                        if not any(row_data.values()):
                            break
                        
                        if row_data == previous_row:  # Sai se for igual à anterior
                            break

                        json_data.append(row_data)
                        previous_row = row_data
                        i += 1

                    df_tabelaExecucao = pd.DataFrame(json_data)
                    df_tabelaExecucao.to_excel(resultado_do_processamento, index=False)

                current_date = datetime.now()
                dataLog = current_date.strftime("%d/%m/%Y %H:%M:%S")

                data.append({
                    "Cod. Empresa": cod_empresa,
                    "Empresa": nome_empresa,
                    "Tipo CTE": tipo_cte,
                    "Mensagem_Saida": "Sucesso!",
                    "DataLog_Saida": dataLog
                })

                if tipo_cte == "subustituição":
                    _FecharSistema()
                else:
                    ui(locator.java.maxys_TAF117.push_button_voltar).click()
                    ui(locator.java.maxys_TAF117.push_button_sair_programa).click()

                print("Sucesso!")

            except BaseException as e:
                if not "A consulta não retornou dados com base nos filtros" in str(e):
                    print(str(e))
                current_date = datetime.now()
                dataLog = current_date.strftime("%d/%m/%Y %H:%M:%S")

                data.append({
                    "Cod. Empresa": cod_empresa,
                    "Empresa": nome_empresa,
                    "Tipo CTE": tipo_cte,
                    "Mensagem_Saida": f"Erro: {str(e)}",
                    "DataLog_Saida": dataLog
                })

                ui(locator.java.maxys_TAF117.push_button_sair_programa).click()

        _FecharSistema()

    # Criar DataFrame final e salvar no Excel
    df = pd.DataFrame(data)
    df.to_excel(excel_Processamento, index=False)